var require = meteorInstall({"client":{"template.main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// client/template.main.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
                                                                                                  // 1
Template.body.addContent((function() {                                                            // 2
  var view = this;                                                                                // 3
  return HTML.Raw('<div id="render-target"></div>');                                              // 4
}));                                                                                              // 5
Meteor.startup(Template.body.renderToDocument);                                                   // 6
                                                                                                  // 7
////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// client/main.jsx                                                                                //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
var React = void 0;                                                                               // 1
module.watch(require("react"), {                                                                  // 1
  "default": function (v) {                                                                       // 1
    React = v;                                                                                    // 1
  }                                                                                               // 1
}, 0);                                                                                            // 1
var Meteor = void 0;                                                                              // 1
module.watch(require("meteor/meteor"), {                                                          // 1
  Meteor: function (v) {                                                                          // 1
    Meteor = v;                                                                                   // 1
  }                                                                                               // 1
}, 1);                                                                                            // 1
var render = void 0;                                                                              // 1
module.watch(require("react-dom"), {                                                              // 1
  render: function (v) {                                                                          // 1
    render = v;                                                                                   // 1
  }                                                                                               // 1
}, 2);                                                                                            // 1
var App = void 0;                                                                                 // 1
module.watch(require("../imports/ui/App.jsx"), {                                                  // 1
  "default": function (v) {                                                                       // 1
    App = v;                                                                                      // 1
  }                                                                                               // 1
}, 3);                                                                                            // 1
Meteor.startup(function () {                                                                      // 7
  render(React.createElement(App, null), document.getElementById('render-target'));               // 8
});                                                                                               // 9
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"api":{"tasks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// imports/api/tasks.js                                                                           //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
module.export({                                                                                   // 1
  Tasks: function () {                                                                            // 1
    return Tasks;                                                                                 // 1
  }                                                                                               // 1
});                                                                                               // 1
var Mongo = void 0;                                                                               // 1
module.watch(require("meteor/mongo"), {                                                           // 1
  Mongo: function (v) {                                                                           // 1
    Mongo = v;                                                                                    // 1
  }                                                                                               // 1
}, 0);                                                                                            // 1
var Tasks = new Mongo.Collection('tasks');                                                        // 3
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ui":{"App.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// imports/ui/App.jsx                                                                             //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                           //
                                                                                                  //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                  //
                                                                                                  //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");     //
                                                                                                  //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);            //
                                                                                                  //
var _inherits2 = require("babel-runtime/helpers/inherits");                                       //
                                                                                                  //
var _inherits3 = _interopRequireDefault(_inherits2);                                              //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
                                                                                                  //
var React = void 0,                                                                               // 1
    Component = void 0;                                                                           // 1
module.watch(require("react"), {                                                                  // 1
  "default": function (v) {                                                                       // 1
    React = v;                                                                                    // 1
  },                                                                                              // 1
  Component: function (v) {                                                                       // 1
    Component = v;                                                                                // 1
  }                                                                                               // 1
}, 0);                                                                                            // 1
var PropTypes = void 0;                                                                           // 1
module.watch(require("prop-types"), {                                                             // 1
  "default": function (v) {                                                                       // 1
    PropTypes = v;                                                                                // 1
  }                                                                                               // 1
}, 1);                                                                                            // 1
var ReactDOM = void 0;                                                                            // 1
module.watch(require("react-dom"), {                                                              // 1
  "default": function (v) {                                                                       // 1
    ReactDOM = v;                                                                                 // 1
  }                                                                                               // 1
}, 2);                                                                                            // 1
var withTracker = void 0;                                                                         // 1
module.watch(require("meteor/react-meteor-data"), {                                               // 1
  withTracker: function (v) {                                                                     // 1
    withTracker = v;                                                                              // 1
  }                                                                                               // 1
}, 3);                                                                                            // 1
var Meteor = void 0;                                                                              // 1
module.watch(require("meteor/meteor"), {                                                          // 1
  Meteor: function (v) {                                                                          // 1
    Meteor = v;                                                                                   // 1
  }                                                                                               // 1
}, 4);                                                                                            // 1
var Tasks = void 0;                                                                               // 1
module.watch(require("../api/tasks.js"), {                                                        // 1
  Tasks: function (v) {                                                                           // 1
    Tasks = v;                                                                                    // 1
  }                                                                                               // 1
}, 5);                                                                                            // 1
var Task = void 0;                                                                                // 1
module.watch(require("./Task.jsx"), {                                                             // 1
  "default": function (v) {                                                                       // 1
    Task = v;                                                                                     // 1
  }                                                                                               // 1
}, 6);                                                                                            // 1
                                                                                                  //
// App component - represents the whole app                                                       // 11
var App = function (_Component) {                                                                 //
  (0, _inherits3.default)(App, _Component);                                                       //
                                                                                                  //
  function App() {                                                                                //
    (0, _classCallCheck3.default)(this, App);                                                     //
    return (0, _possibleConstructorReturn3.default)(this, _Component.apply(this, arguments));     //
  }                                                                                               //
                                                                                                  //
  App.prototype.handleSubmit = function () {                                                      //
    function handleSubmit(event) {                                                                //
      event.preventDefault(); // Find the text field via the React ref                            // 14
                                                                                                  //
      var text = ReactDOM.findDOMNode(this.refs.textInput).value.trim();                          // 17
      Tasks.insert({                                                                              // 19
        text: text,                                                                               // 20
        createdAt: new Date() // current time                                                     // 21
                                                                                                  //
      }); // Clear form                                                                           // 19
                                                                                                  //
      ReactDOM.findDOMNode(this.refs.textInput).value = '';                                       // 25
    }                                                                                             // 26
                                                                                                  //
    return handleSubmit;                                                                          //
  }();                                                                                            //
                                                                                                  //
  App.prototype.renderTasks = function () {                                                       //
    function renderTasks() {                                                                      //
      return this.props.tasks.map(function (task) {                                               // 29
        return React.createElement(Task, {                                                        // 29
          key: task._id,                                                                          // 30
          task: task                                                                              // 30
        });                                                                                       // 30
      });                                                                                         // 29
    }                                                                                             // 32
                                                                                                  //
    return renderTasks;                                                                           //
  }();                                                                                            //
                                                                                                  //
  App.prototype.render = function () {                                                            //
    function render() {                                                                           //
      return React.createElement(                                                                 // 35
        "div",                                                                                    // 36
        {                                                                                         // 36
          className: "container"                                                                  // 36
        },                                                                                        // 36
        React.createElement(                                                                      // 37
          "header",                                                                               // 37
          null,                                                                                   // 37
          React.createElement(                                                                    // 38
            "h1",                                                                                 // 38
            null,                                                                                 // 38
            "Todo List"                                                                           // 38
          ),                                                                                      // 38
          React.createElement(                                                                    // 40
            "form",                                                                               // 40
            {                                                                                     // 40
              className: "new-task",                                                              // 40
              onSubmit: this.handleSubmit.bind(this)                                              // 40
            },                                                                                    // 40
            React.createElement("input", {                                                        // 41
              type: "text",                                                                       // 42
              ref: "textInput",                                                                   // 43
              placeholder: "Type to add new tasks"                                                // 44
            })                                                                                    // 41
          )                                                                                       // 40
        ),                                                                                        // 37
        React.createElement(                                                                      // 49
          "ul",                                                                                   // 49
          null,                                                                                   // 49
          this.renderTasks()                                                                      // 50
        )                                                                                         // 49
      );                                                                                          // 36
    }                                                                                             // 54
                                                                                                  //
    return render;                                                                                //
  }();                                                                                            //
                                                                                                  //
  return App;                                                                                     //
}(Component);                                                                                     //
                                                                                                  //
App.propTypes = {                                                                                 // 57
  tasks: PropTypes.array.isRequired                                                               // 58
};                                                                                                // 57
module.exportDefault(withTracker(function (props) {                                               // 1
  return {                                                                                        // 62
    tasks: Tasks.find({}, {                                                                       // 63
      sort: {                                                                                     // 63
        createdAt: -1                                                                             // 63
      }                                                                                           // 63
    }).fetch()                                                                                    // 63
  };                                                                                              // 62
})(App));                                                                                         // 65
////////////////////////////////////////////////////////////////////////////////////////////////////

},"Task.jsx":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// imports/ui/Task.jsx                                                                            //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                           //
                                                                                                  //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                  //
                                                                                                  //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");     //
                                                                                                  //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);            //
                                                                                                  //
var _inherits2 = require("babel-runtime/helpers/inherits");                                       //
                                                                                                  //
var _inherits3 = _interopRequireDefault(_inherits2);                                              //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
                                                                                                  //
module.export({                                                                                   // 1
  "default": function () {                                                                        // 1
    return Task;                                                                                  // 1
  }                                                                                               // 1
});                                                                                               // 1
var React = void 0,                                                                               // 1
    Component = void 0;                                                                           // 1
module.watch(require("react"), {                                                                  // 1
  "default": function (v) {                                                                       // 1
    React = v;                                                                                    // 1
  },                                                                                              // 1
  Component: function (v) {                                                                       // 1
    Component = v;                                                                                // 1
  }                                                                                               // 1
}, 0);                                                                                            // 1
var PropTypes = void 0;                                                                           // 1
module.watch(require("prop-types"), {                                                             // 1
  "default": function (v) {                                                                       // 1
    PropTypes = v;                                                                                // 1
  }                                                                                               // 1
}, 1);                                                                                            // 1
var Tasks = void 0;                                                                               // 1
module.watch(require("../api/tasks.js"), {                                                        // 1
  Tasks: function (v) {                                                                           // 1
    Tasks = v;                                                                                    // 1
  }                                                                                               // 1
}, 2);                                                                                            // 1
                                                                                                  //
var Task = function (_Component) {                                                                //
  (0, _inherits3.default)(Task, _Component);                                                      //
                                                                                                  //
  function Task() {                                                                               //
    (0, _classCallCheck3.default)(this, Task);                                                    //
    return (0, _possibleConstructorReturn3.default)(this, _Component.apply(this, arguments));     //
  }                                                                                               //
                                                                                                  //
  Task.prototype.toggleChecked = function () {                                                    //
    function toggleChecked() {                                                                    //
      // Set the checked property to the opposite of its current value                            // 9
      Tasks.update(this.props.task._id, {                                                         // 10
        $set: {                                                                                   // 11
          checked: !this.props.task.checked                                                       // 11
        }                                                                                         // 11
      });                                                                                         // 10
    }                                                                                             // 13
                                                                                                  //
    return toggleChecked;                                                                         //
  }();                                                                                            //
                                                                                                  //
  Task.prototype.deleteThisTask = function () {                                                   //
    function deleteThisTask() {                                                                   //
      Tasks.remove(this.props.task._id);                                                          // 16
    }                                                                                             // 17
                                                                                                  //
    return deleteThisTask;                                                                        //
  }();                                                                                            //
                                                                                                  //
  Task.prototype.render = function () {                                                           //
    function render() {                                                                           //
      // Give tasks a different className when they are checked off,                              // 20
      // so that we can style them nicely in CSS                                                  // 21
      var taskClassName = this.props.task.checked ? 'checked' : '';                               // 22
      return React.createElement(                                                                 // 24
        "li",                                                                                     // 25
        {                                                                                         // 25
          className: taskClassName                                                                // 25
        },                                                                                        // 25
        React.createElement(                                                                      // 26
          "button",                                                                               // 26
          {                                                                                       // 26
            className: "delete",                                                                  // 26
            onClick: this.deleteThisTask.bind(this)                                               // 26
          },                                                                                      // 26
          "\xD7"                                                                                  // 26
        ),                                                                                        // 26
        React.createElement("input", {                                                            // 30
          type: "checkbox",                                                                       // 31
          readOnly: true,                                                                         // 32
          checked: this.props.task.checked,                                                       // 33
          onClick: this.toggleChecked.bind(this)                                                  // 34
        }),                                                                                       // 30
        React.createElement(                                                                      // 37
          "span",                                                                                 // 37
          {                                                                                       // 37
            className: "text"                                                                     // 37
          },                                                                                      // 37
          this.props.task.text                                                                    // 37
        )                                                                                         // 37
      );                                                                                          // 25
    }                                                                                             // 40
                                                                                                  //
    return render;                                                                                //
  }();                                                                                            //
                                                                                                  //
  return Task;                                                                                    //
}(Component);                                                                                     //
                                                                                                  //
Task.propTypes = {                                                                                // 43
  // This component gets the task to display through a React prop.                                // 44
  // We can use propTypes to indicate it is required                                              // 45
  task: PropTypes.object.isRequired                                                               // 46
};                                                                                                // 43
////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json",
    ".html",
    ".jsx",
    ".css"
  ]
});
require("./client/template.main.js");
require("./client/main.jsx");